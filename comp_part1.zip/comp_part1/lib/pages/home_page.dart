import 'package:comp_part1/pages/add_page.dart';
import 'package:comp_part1/pages/profile_page.dart';
import 'package:flutter/material.dart';

const Color customBackground = Color(0xffe6e6ec);
const Color customBlue = Color(0xff0e4e93);
const Color customOceanBlue = Color(0xff638181);
const Color customBlack54 = Colors.black54;
const Color customBackgroundWhite = Colors.white;

const TextStyle customHeadline1 =
TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: customBlack54);
const TextStyle customHeadline2 =
TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: customBlue);
const TextStyle customBodyText =
TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: customBlack54);


class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: ListView(
          children: const [
            Padding(
              padding: EdgeInsets.fromLTRB(8, 10, 8, 0),
              child: customAppBar(),
            ),
            SizedBox(
              height: 20,
            ),
            itemListContainer(),
            SizedBox(
              height: 20,
            ),
            itemListContainer(),
            SizedBox(
              height: 20,
            ),
            itemListContainer(),
            SizedBox(
              height: 20,
            ),
          ],
        ),
        floatingActionButton: addButton(),
      ),
    );
  }
}

class addButton extends StatelessWidget {
  const addButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      heroTag: null,
      backgroundColor: customOceanBlue,
      foregroundColor: customBackgroundWhite,
      onPressed: () {},
      child: GestureDetector(
        onTap: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => AddPage()));
        },
        child: Icon(
          Icons.add,
          size: 35,
        ),
      ),
    );
  }
}

class cardList extends StatefulWidget {
  cardList({Key? key}) : super(key: key);

  @override
  State<cardList> createState() => _cardListState();
}

class _cardListState extends State<cardList> {
  var currentItem = itemList.getData;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      scrollDirection: Axis.horizontal,
      itemCount: currentItem.length,
      itemBuilder: (context, index) {
        return SizedBox(
          width: 180,
          child: Stack(
            children: [
              Card(
                elevation: 4,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 15, 7, 7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0, 5, 0, 10),
                        child: Container(
                          height: 90.0,
                          width: 90.0,
                          decoration: BoxDecoration(
                            color: customBackground,
                            borderRadius: const BorderRadius.all(
                              Radius.circular(8.0),
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(.5),
                                blurRadius: 3.0,
                                spreadRadius: 0.0,
                                offset: const Offset(
                                  0.0,
                                  3.0,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Text(
                        currentItem[index]['name'].toString(),
                        style: customHeadline2,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      const Divider(
                        height: 0,
                        thickness: 1,
                        endIndent: 20,
                        color: Colors.black26,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        currentItem[index]['brand'].toString(),
                        style: customBodyText,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Text(
                        currentItem[index]['type'].toString(),
                        style: customBodyText,
                      ),
                    ],
                  ),
                ),
              ),
              editButton(),
            ],
          ),
        );
      },
    );
  }
}

class editButton extends StatelessWidget {
  const editButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: 18,
      left: 85,
      child: SizedBox(
        height: 30,
        width: 30,
        child: FloatingActionButton(
          heroTag: null,
          shape: RoundedRectangleBorder(
            side: const BorderSide(width: 1, color: customBlue),
            borderRadius: BorderRadius.circular(8),
          ),
          backgroundColor: customBackground,
          mini: true,
          foregroundColor: customBlue,
          onPressed: () {

          },
          child: const Icon(
            Icons.edit,
          ),
        ),
      ),
    );
  }
}

class itemListContainer extends StatelessWidget {
  const itemListContainer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: 270,
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.all(
            Radius.circular(8.0),
          ),
          color: customBackground,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              blurRadius: 5.0,
              spreadRadius: 0.0,
              offset: const Offset(
                0.0,
                5.0,
              ),
            ),
          ],
        ),
        child: Column(
          children: [
           Padding(
              padding: EdgeInsets.only(left: 8.0),
              child: Row(

                children: [
                  Expanded(
                  flex: 2,
                  child: Text(
                    "Last 1 Day!",
                    style: customHeadline1,
                  ),
                ),]
              ),
            ),
            Expanded(
              flex: 7,
              child: cardList(),
            ),
            const Expanded(
              flex: 0,
              child: Text(""),
            ),
          ],
        ),
      ),
    );
  }
}

class itemList {
  static final getData = [
    {
      'name': 'name1',
      'thumbnail': 'thumbnail1',
      'brand': 'brand1',
      'type': 'type1',
    },
    {
      'name': 'name2',
      'thumbnail': 'thumbnail2',
      'brand': 'brand2',
      'type': 'type2',
    },
    {
      'name': 'name3',
      'thumbnail': 'thumbnail3',
      'brand': 'brand3',
      'type': 'type3',
    },
    {
      'name': 'name4',
      'thumbnail': 'thumbnail4',
      'brand': 'brand4',
      'type': 'type4',
    },
    {
      'name': 'name5',
      'thumbnail': 'thumbnail5',
      'brand': 'brand5',
      'type': 'type5',
    },
  ];
}

class customAppBar extends StatelessWidget {
  const customAppBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 51,
      child: Row(
        children: <Widget>[
          Expanded(
            child: TextField(
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: "Search",
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.0),
                    borderSide: BorderSide.none),
                fillColor: customBackground,
                filled: true,
              ),
            ),
          ),
          const SizedBox(width: 15),
          Container(
            decoration: BoxDecoration(
              color: customBackground,
              borderRadius: BorderRadius.circular(9.0),
            ),
            child: IconButton(
              icon: const Icon(Icons.person_outline),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => ProfilePage()));
              },
            ),
          ),
        ],
      ),
    );
  }
}
