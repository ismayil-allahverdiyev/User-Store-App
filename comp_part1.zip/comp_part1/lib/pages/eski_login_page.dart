import 'package:comp_part1/pages/home_page.dart';
import 'package:comp_part1/pages/eski_signup.dart';

import 'package:comp_part1/widgets/SignInSignUpButton.dart';
import 'package:comp_part1/widgets/rounded_password_fiel.dart';
import 'package:flutter/material.dart';

import '../widgets/already_havean_account_check.dart';
import '../widgets/rounded_input_field.dart';
import 'forgot_password_page.dart';


class LoginScreen extends StatelessWidget {
   LoginScreen({
    Key? key, required this.image,
  }) : super(key: key);
 final String image;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
        color: Colors.white,
        width: double.infinity,
        height: size.height,
        child: Hero(
          tag: image,
          child: ListView(
          children: <Widget> [
            SizedBox(height: 30,),
            Card(
              elevation: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Flexible(
                    child: Card(
                      elevation: 0,
                      child: Container(
                        width: width/2,
                        height: width/3,
                        decoration: BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage(image),
                                fit: BoxFit.fill
                            )
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget> [

                Card(
                  elevation: 0
                    ,child: Text("LOGIN", style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),)),
                SizedBox(height: size.height*0.03,),
                RoundedInputField(
                  hintText: "Your Email",
                  icon: Icons.person,
                  onChanged: (value){},
                ),
                SizedBox(height: size.height*0.03,),
                RoundedPasswordField(onChanged: (value){},title: 'Password'),
                SizedBox(height: size.height*0.03,),
                SingInSingUpButton(context: context,
                  boyut: 0.8,
                  isLogin: true, onTap: (){
                 Navigator.push(context, MaterialPageRoute(builder: (context) => Home()));
                }, ),
                SizedBox(height: size.height*0.03,),
                Card(
                  elevation:0 ,
                  child: GestureDetector(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordPage()));
                      },
                      child: Text("Forgot Password?")),
                )
              ],
            ),
          ),],
      ),
        ),),
    );
  }
}









