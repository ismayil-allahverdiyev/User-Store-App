import 'package:flutter/material.dart';
import 'package:comp_part1/pages/edit_page.dart';
import 'package:comp_part1/widgets/date_widget.dart';
import 'package:comp_part1/widgets/time_widget.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';

enum Discounts{discountBy25, discountBy50, userChoice}

class AddPage extends StatefulWidget {
  const AddPage({Key? key}) : super(key: key);

  @override
  _AddPageState createState() => _AddPageState();
}

class _AddPageState extends State<AddPage> {

  int x = 19;



  Discounts? discounts = Discounts.discountBy25;

  var expiryDate;

  bool openTypeSelector = false;

  bool hasDiscount = false;

  int discountAmount = 0;

  @override
  Widget build(BuildContext context) {

    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    var currentDate = DateTime.now();

    int currentDay = currentDate.day;
    int currentMonth = currentDate.month;
    int currentYear = currentDate.year;

    int currentMin = currentDate.minute;
    int currentHour = currentDate.hour;


    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.of(context).push(MaterialPageRoute(builder: (context) => EditPage()));
        },
        child: Icon(Icons.add, color: Colors.white, size: height*0.03,),
        elevation: 10,
        backgroundColor: Color(0xffa1c6ea),
      ),
      appBar: AppBar(

        title: Text("Add page"),
        backgroundColor: Color(0xffa1c6ea),
      ),
      body: GestureDetector(
        onTap: (){
          FocusScopeNode currentScope = FocusScope.of(context);

          if(!currentScope.hasPrimaryFocus){
            currentScope.unfocus();
          }
        },
        child: SafeArea(
          child: ListView(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(15.0, 8, 8,8),
                child: Row(
                  // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Card(
                      elevation: 10,
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Container(
                          width: width*0.3,
                          height: width*0.08,
                          decoration: const BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage("assets/images/A101_logo.png"),
                                  fit: BoxFit.fill
                              )
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: height*0.08,),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          TimeWidget(currentHour: currentHour, currentMin: currentMin),
                          DateWidget(currentDay: currentDay, currentMonth: currentMonth, currentYear: currentYear)
                        ],
                      ),
                    )
                  ],
                ),
              ),
              // SizedBox(height: height*0.05,),
              Padding(
                padding: const EdgeInsets.fromLTRB(15.0, 25, 0, 10),
                child: Card(
                  elevation: 10,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(bottomLeft: Radius.circular(20), topLeft: Radius.circular(20))
                  ),
                  child: Container(
                    height: width/2.3,
                    width: width,
                    decoration: const BoxDecoration(
                        color: Color(0xffa1c6ea),
                        borderRadius: BorderRadius.only(bottomLeft: Radius.circular(20), topLeft: Radius.circular(20))
                    ),
                    child: Center(
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              width: width/1.5,
                              decoration: const BoxDecoration(
                                  color: Color(0xffdae3e5),
                                  borderRadius: BorderRadius.all(Radius.circular(20))
                              ),
                              child: Center(
                                child: Text("+", style: TextStyle(fontSize: height*0.1, color: Colors.grey),),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              width: width/1.5,
                              decoration: const BoxDecoration(
                                  color: Color(0xffdae3e5),
                                  borderRadius: BorderRadius.all(Radius.circular(20))
                              ),
                              child: Center(
                                child: Text("+", style: TextStyle(fontSize: height*0.1, color: Colors.grey),),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding:  EdgeInsets.fromLTRB(width/4, 10, width/4, 10),
                child: Divider(
                  color: Colors.grey,
                  thickness: 3,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                child: Card(
                  elevation: 6,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                    child: TextField(
                      decoration: InputDecoration(
                        labelText: "Title",
                        suffixIcon: Icon(
                          Icons.create,
                          size: height*0.025,
                          color: Colors.grey,
                        ),
                        floatingLabelStyle: TextStyle(
                          color: Colors.blueGrey,
                          fontSize: height*0.025,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                        labelStyle: TextStyle(
                          color: const Color(0xff00798c),
                          fontSize: height*0.02,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                        focusedBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                        ),
                        disabledBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                        ),
                        enabledBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                child: Card(
                  elevation: 6,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                    child: TextField(
                      decoration: InputDecoration(
                        labelText: "Description",
                        suffixIcon: Icon(
                          Icons.create,
                          size: height*0.025,
                          color: Colors.grey,
                        ),
                        floatingLabelStyle: TextStyle(
                          color: Colors.blueGrey,
                          fontSize: height*0.025,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                        labelStyle: TextStyle(
                          color: const Color(0xff00798c),
                          fontSize: height*0.02,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                        focusedBorder:const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                        ),
                        disabledBorder:const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                        ),
                        enabledBorder:const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding:  EdgeInsets.fromLTRB(width/4, 10, width/4, 10),
                child: Divider(
                  color: Colors.grey,
                  thickness: 3,
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Row(
                    children: [
                      IconButton(onPressed: (){}, icon: Icon(Icons.remove_circle_outline, size: height*0.03, color: Color(0xff986c6a),)),
                      Card(
                        elevation: 6,
                        shape:const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(5))
                        ),
                        child: SizedBox(
                          height: 50,
                          width: 100,
                          child: TextField(
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                              labelText: "Amount",
                              floatingLabelStyle: TextStyle(
                                color: Colors.blueGrey,
                                fontSize: height*0.02,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.5,
                              ),
                              labelStyle: const TextStyle(
                                color: Color(0xff00798c),
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.5,
                              ),
                              focusedBorder:const OutlineInputBorder(
                                  borderRadius: BorderRadius.all(Radius.circular(5)),
                                  borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                              ),
                              disabledBorder:const OutlineInputBorder(
                                  borderRadius: BorderRadius.all(Radius.circular(5)),
                                  borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                              ),
                              enabledBorder:const OutlineInputBorder(
                                  borderRadius: BorderRadius.all(Radius.circular(5)),
                                  borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                              ),
                            ),
                          ),
                        ),
                      ),
                      IconButton(onPressed: (){}, icon: Icon(Icons.add_circle_outline, size: height*0.03, color: Color(0xff986c6a))),
                    ],
                  ),
                  Card(
                    elevation: 6,
                    shape:const RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(5))
                    ),
                    child: Container(
                      height: 50,
                      width: 120,
                      child: Center(
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
                            child: TextField(
                              decoration: InputDecoration(
                                labelText: "Quantity",
                                floatingLabelStyle: TextStyle(
                                  color: Colors.blueGrey,
                                  fontSize: height*0.02,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.5,
                                ),
                                labelStyle: const TextStyle(
                                  color: Color(0xff00798c),
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.5,
                                ),
                                focusedBorder: const OutlineInputBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(10)),
                                    borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                                ),
                                disabledBorder: const OutlineInputBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(10)),
                                    borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                                ),
                                enabledBorder: const OutlineInputBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(10)),
                                    borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                                ),
                              ),
                            ),
                          )
                      ),
                    ),
                  )
                ],
              ),
              Padding(
                padding:  EdgeInsets.fromLTRB(width/4, 10, width/4, 10),
                child: Divider(
                  color: Colors.grey,
                  thickness: 3,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 0, 5),
                child: Text(
                  "Expiry Date",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Color(0xff00798c),
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.5,
                      fontSize: height*0.02
                  ),
                ),
              ),
              GestureDetector(
                onTap: (){
                  DatePicker.showDatePicker(
                    context,
                    maxTime: DateTime(currentYear+1, 12, 31),
                    onChanged: (date){
                      setState(() {
                        expiryDate = date;
                      });
                    },
                    onConfirm: (date){
                      setState(() {
                        expiryDate = date;
                      });
                      print(date);
                    },
                  );
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Card(
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Text(
                          expiryDate == null?"$currentDay":"${expiryDate.toString().substring(8,10)}",
                          style: TextStyle(
                              fontSize: height*0.025,
                              fontStyle: FontStyle.italic,
                              fontWeight: FontWeight.bold
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Text(
                        "/",
                        style: TextStyle(
                            fontSize: height*0.025,
                            fontStyle: FontStyle.italic,
                            fontWeight: FontWeight.bold
                        ),
                      ),
                    ),
                    Card(
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Text(
                          expiryDate == null?"$currentMonth":"${expiryDate.toString().substring(5,7)}",
                          style: TextStyle(
                              fontSize: height*0.025,
                              fontStyle: FontStyle.italic,
                              fontWeight: FontWeight.bold
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Text(
                        "/",
                        style: TextStyle(
                            fontSize: height*0.025,
                            fontStyle: FontStyle.italic,
                            fontWeight: FontWeight.bold
                        ),
                      ),
                    ),
                    Card(
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Text(
                          expiryDate == null?"$currentYear":"${expiryDate.toString().substring(0,4)}",
                          style: TextStyle(
                              fontSize: height*0.025,
                              fontStyle: FontStyle.italic,
                              fontWeight: FontWeight.bold
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding:  EdgeInsets.fromLTRB(width/4, 10, width/4, 10),
                child: Divider(
                  color: Colors.grey,
                  thickness: 3,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(25, 0, 25, 0),
                child: GestureDetector(
                  onTap: (){
                    setState(() {
                      openTypeSelector == false ? openTypeSelector = true : openTypeSelector = false;
                    });
                  },
                  child: Card(
                      elevation: 10,
                      child: SizedBox(
                        height: 50,
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "Choose type",
                                style: TextStyle(
                                    color: Color(0xff00798c),
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1.5,
                                    fontSize: height*0.02
                                ),
                              ),
                              Icon(openTypeSelector == false?Icons.keyboard_arrow_down:Icons.keyboard_arrow_up)
                            ],
                          ),
                        ),
                      )
                  ),
                ),
              ),
              AnimatedPadding(
                duration: Duration(milliseconds: 500),
                padding: EdgeInsets.fromLTRB(15, openTypeSelector?10:0, 15, 0),
                child: Card(
                  elevation: 10,
                  child: AnimatedSize(
                    duration: Duration(milliseconds: 500),
                    child: Container(
                      height: openTypeSelector?200:0,
                      width: width,
                    ),
                  ),
                ),
              ),
              Padding(
                padding:  EdgeInsets.fromLTRB(width/4, 10, width/4, 10),
                child: Divider(
                  color: Colors.grey,
                  thickness: 3,
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Add discount",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Color(0xff00798c),
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                        fontSize: height*0.02
                    ),
                  ),
                  Checkbox(
                      value: hasDiscount,
                      onChanged: (value){
                        setState(() {
                          hasDiscount = value!;
                        });
                        print(hasDiscount);
                      }
                  )
                ],
              ),
              AnimatedSize(
                duration: Duration(milliseconds: 500),
                child: Container(
                  height: hasDiscount?100:0,
                  width: width,
                  child: Row(
                    children: [
                      Column(
                        children: [
                          Container(
                            width:200,
                            height: 50,
                            child: RadioListTile<Discounts>(
                              title: Text(
                                "25% discount",
                                style: TextStyle(
                                    color: discounts != Discounts.userChoice?Colors.black:Colors.grey,
                                    fontWeight: FontWeight.bold
                                ),
                              ),
                              value: Discounts.discountBy25,
                              groupValue: discounts,
                              onChanged: (Discounts? value) {
                                setState(() {
                                  discounts = value!;
                                });
                              },
                            ),
                          ),
                          Container(
                            width:200,
                            height: 50,
                            child: RadioListTile<Discounts>(
                              title: Text(
                                "50% discount",
                                style: TextStyle(
                                    color: discounts != Discounts.userChoice?Colors.black:Colors.grey,
                                    fontWeight: FontWeight.bold
                                ),
                              ),
                              value: Discounts.discountBy50,
                              groupValue: discounts,
                              onChanged: (Discounts? value) {
                                setState(() {
                                  discounts = value!;
                                });
                              },
                            ),
                          )
                        ],
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          AnimatedSize(
                            duration:Duration(milliseconds: 500),
                            child: Container(
                              width:170,
                              height: hasDiscount?60:0,
                              child: RadioListTile<Discounts>(
                                title: Text(
                                  "Custom discount",

                                  style: TextStyle(
                                      color: discounts == Discounts.userChoice?Colors.black:Colors.grey,
                                      fontWeight: FontWeight.bold
                                  ),
                                ),
                                value: Discounts.userChoice,
                                groupValue: discounts,
                                onChanged: (Discounts? value) {
                                  setState(() {
                                    discounts = value!;
                                  });
                                  print(discounts);
                                },
                              ),
                            ),
                          ),
                          Card(
                            elevation: 6,
                            shape:const RoundedRectangleBorder(
                                borderRadius: BorderRadius.all(Radius.circular(5))
                            ),
                            child: AnimatedSize(
                              duration: Duration(milliseconds: 500),
                              child: SizedBox(
                                height: hasDiscount?50:0,
                                width: 70,
                                child: TextField(
                                  keyboardType: TextInputType.number,
                                  decoration: InputDecoration(
                                    hintText: "%",
                                    hintStyle: TextStyle(
                                        color: discounts == Discounts.userChoice?Color(0xff00798c):Colors.grey,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 1.5,
                                        fontSize: height*0.02
                                    ),
                                    floatingLabelStyle: TextStyle(
                                      color: Colors.blueGrey,
                                      fontSize: height*0.02,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1.5,
                                    ),
                                    labelStyle: const TextStyle(
                                      color: Color(0xff00798c),
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1.5,
                                    ),
                                    focusedBorder:const OutlineInputBorder(
                                        borderRadius: BorderRadius.all(Radius.circular(5)),
                                        borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                                    ),
                                    disabledBorder:const OutlineInputBorder(
                                        borderRadius: BorderRadius.all(Radius.circular(5)),
                                        borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                                    ),
                                    enabledBorder:const OutlineInputBorder(
                                        borderRadius: BorderRadius.all(Radius.circular(5)),
                                        borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding:  EdgeInsets.fromLTRB(width/4, 10, width/4, 10),
                child: Divider(
                  color: Colors.grey,
                  thickness: 3,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                child: Card(
                  elevation: 6,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                    child: TextField(
                      decoration: InputDecoration(
                        labelText: "Brand Name",
                        suffixIcon: Icon(
                          Icons.create,
                          size: height*0.025,
                          color: Colors.grey,
                        ),
                        floatingLabelStyle: TextStyle(
                          color: Colors.blueGrey,
                          fontSize: height*0.025,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                        labelStyle: TextStyle(
                          color: const Color(0xff00798c),
                          fontSize: height*0.02,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                        focusedBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                        ),
                        disabledBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                        ),
                        enabledBorder: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            borderSide: BorderSide(color: Colors.white, style: BorderStyle.none, width: 0)
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding:  EdgeInsets.fromLTRB(width/4, 10, width/4, 10),
                child: Divider(
                  color: Colors.grey,
                  thickness: 3,
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(20, 0, width/2.5, 0),
                child: GestureDetector(
                  onTap: (){
                    setState(() {
                      openTypeSelector == false ? openTypeSelector = true : openTypeSelector = false;
                    });
                  },
                  child: Card(
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(10))
                      ),
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(0, 15, 0, 15),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                " Add Nutrients ",
                                style: TextStyle(
                                    color: Color(0xff00798c),
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1.5,
                                    fontSize: height*0.02
                                ),
                              ),
                              Icon(Icons.add, color: Color(0xff00798c),)
                            ],
                          ),
                        ),
                      )
                  ),
                ),
              ),
              AnimatedPadding(
                duration: Duration(milliseconds: 500),
                padding: EdgeInsets.fromLTRB(15, openTypeSelector?10:0, 15, 0),
                child: Card(
                  elevation: 10,
                  child: AnimatedSize(
                    duration: Duration(milliseconds: 500),
                    child: Container(
                      height: openTypeSelector?200:0,
                      width: width,
                    ),
                  ),
                ),
              ),
              SizedBox(height: height*0.05,)
            ],
          ),
        ),
      ),
    );
  }
}
