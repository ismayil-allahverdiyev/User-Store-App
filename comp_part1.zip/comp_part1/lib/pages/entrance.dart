import 'package:comp_part1/widgets/brand.dart';
import 'package:flutter/material.dart';

import 'anonymous_signup_page.dart';

class Entrance extends StatelessWidget {
  const Entrance({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(60.0),
        child: ListView(
          children: [
            SizedBox(height: height*0.1,),
            Column(
              children: [
                Brand(width: width,
                brand: 'assets/images/a101.jpg',),
                Brand(width: width,
                  brand: 'assets/images/bim.png',),
                Brand(width: width,
                  brand: 'assets/images/migros.jpg',),
                Brand(width: width,
                  brand: 'assets/images/sok_logo.jpeg',),
                SizedBox(height: height*0.1,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: GestureDetector(
                        onTap: (){
                          Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => AnSignUpPage()));
                        },
                        child: Card(
                          color: Colors.red,
                          elevation: 10,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10))
                          ),
                          child: SizedBox(
                            height: 50,
                            width: 150,
                            child: Center(
                              child: Text("Sign Up", style: TextStyle(fontSize: height*0.02, color: Colors.white, fontWeight: FontWeight.bold),)
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                )

   ], ),
          ],
        ),
      ),);
  }
}

