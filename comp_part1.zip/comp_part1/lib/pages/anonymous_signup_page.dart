import 'package:comp_part1/pages/eski_login_page.dart';
import 'package:comp_part1/widgets/SignInSignUpButton.dart';
import 'package:comp_part1/widgets/already_havean_account_check.dart';
import 'package:comp_part1/widgets/rounded_input_field.dart';
import 'package:comp_part1/widgets/rounded_password_fiel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';



class AnSignUpPage extends StatefulWidget {

  AnSignUpPage({Key? key,}) : super(key: key);

  @override
  State<AnSignUpPage> createState() => _AnSignUpPageState();
}

class _AnSignUpPageState extends State<AnSignUpPage> {
  List<String> markets = ["A101", "Bim", "Migros", "Şok"];

  String? selectedMarket;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
          color: Colors.white,
          width: double.infinity,
          height: size.height,
          child: ListView(
              children: <Widget> [
                SizedBox(height: size.height*0.15),
                SingleChildScrollView(
                  child: Column(
                    children:<Widget> [
                      Text("SIGN UP", style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),),
                      SizedBox(height: height*0.02,),
                      RoundedInputField(
                        hintText: "User Name",
                        icon: Icons.person,
                        onChanged: (value){},
                      ),
                      RoundedInputField(
                        hintText: "Your Email",
                        icon: Icons.mail_outline,
                        onChanged: (value){},
                      ),
                      RoundedPasswordField(onChanged: (value){}, title: 'Password',),
                      RoundedPasswordField(onChanged: (value){}, title: 'Password Again',),
                      Container(
                        child: Padding(
                          padding: const EdgeInsets.all(25.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [

                              Card(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(50)),
                              elevation: 10,
                              color:  Color(0xffa1c6ea),
                              child: DropdownButton(
                                borderRadius: BorderRadius.circular(10),
                                elevation: 50,
                                dropdownColor: Colors.black26,
                                value: selectedMarket,
                                onChanged: (value){
                                  setState((){
                                    selectedMarket = value.toString();
                                  });
                                },
                                hint: Padding(
                                  padding: const EdgeInsets.only(left: 5.0),
                                  child: Text("Please select a market", style: TextStyle(color: Colors.white),),
                                ),
                                items: markets.map((String name) {
                                  return DropdownMenuItem<String>(
                                    value: name,
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: 40),
                                      child: Text(name),
                                    ),);

                                }).toList(),
                              ),
                            ),

                              SingInSingUpButton(context: context,
                                  boyut:  0.25,
                                  isLogin: false, onTap: () {
                                // Navigator.push(context, MaterialPageRoute(builder: (context) => LoginScreen(image: )));},
                              } ),

                            ],
                          ),
                        ),
                      ),

                      SizedBox(height: size.height*0.0001,),


                    ],

                  ),
                ),]
          )),
    );
  }
}

