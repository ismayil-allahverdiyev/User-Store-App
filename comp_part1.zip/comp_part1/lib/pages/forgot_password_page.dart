import 'package:comp_part1/widgets/SignInSignUpButton.dart';
import 'package:comp_part1/widgets/rounded_input_field.dart';
import 'package:comp_part1/widgets/rounded_password_fiel.dart';
import 'package:flutter/material.dart';

class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({Key? key}) : super(key: key);

  @override
  _ForgotPasswordPageState createState() => _ForgotPasswordPageState();
}
class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
          color: Colors.white,
          width: double.infinity,
          height: size.height,
          child: ListView(
              children: <Widget> [
                SingleChildScrollView(
                  child: Column(
                    children:<Widget> [

                      SizedBox(height: height * 0.3,),
                      Text("Reset Password", style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),),
                      SizedBox(height: size.height*0.03,),
                      RoundedInputField(
                        hintText: "Your Email Address",
                        icon: Icons.email_outlined,
                        onChanged: (value){},
                      ),
                      SizedBox(height: size.height*0.03,),
                      RoundedPasswordField(onChanged: (value){}, title: "Password",),
                      SizedBox(height: size.height*0.03,),
                      SingInSingUpButton(context: context,
                        isLogin: true,
                        boyut: 0.8,
                        onTap: (){
                          //Navigator.push(context, MaterialPageRoute(builder: (context) => LoginScreen(image: image)));
                        },),
                      SizedBox(height: size.height*0.0001,),


                    ],

                  ),
                ),]
          )),
    );
  }
}
