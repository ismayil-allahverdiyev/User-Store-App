
import 'package:comp_part1/pages/eski_login_page.dart';
import 'package:comp_part1/widgets/SignInSignUpButton.dart';
import 'package:comp_part1/widgets/already_havean_account_check.dart';
import 'package:comp_part1/widgets/rounded_input_field.dart';
import 'package:comp_part1/widgets/rounded_password_fiel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';



class SignUpPage extends StatelessWidget {

  final String image;
   SignUpPage({Key? key, required this.image}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
          color: Colors.white,
          width: double.infinity,
          height: size.height,
          child: ListView(
        children: <Widget> [
          Card(
            elevation: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Flexible(
                  child: Card(
                    elevation: 0,
                    child: Container(
                      width: width/2,
                      height: width/3,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage(image),
                              fit: BoxFit.fill
                          )
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SingleChildScrollView(
          child: Column(
            children:<Widget> [
              Text("SIGN UP", style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),),
              RoundedInputField(
                hintText: "User Name",
                icon: Icons.person,
                onChanged: (value){},
              ),
              RoundedInputField(
                hintText: "Your Email",
                icon: Icons.mail_outline,
                onChanged: (value){},
              ),
              RoundedPasswordField(onChanged: (value){}, title: 'Password',),
              RoundedPasswordField(onChanged: (value){}, title: 'Password Again',),
              SingInSingUpButton(context: context,
                isLogin: false,
                boyut: 0.8,
                onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => LoginScreen(image: image)));
              },),


            ],

          ),
        ),]
      )),
    );
  }
}

