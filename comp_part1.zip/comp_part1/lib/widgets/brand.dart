import 'package:comp_part1/pages/eski_login_page.dart';
import 'package:flutter/material.dart';
class Brand extends StatelessWidget {
  const Brand({
    Key? key,
    required this.width,
    required this.brand,
  }) : super(key: key);

  final double width;
  final String brand;

  @override
  Widget build(BuildContext context) {

    return GestureDetector(
      onTap: () => Navigator.of(context).push(
          PageRouteBuilder(pageBuilder: (context, animation, secondaryAnimation) =>
              LoginScreen(image: brand),
            transitionDuration: Duration(seconds: 3),
            transitionsBuilder: (context, animation, secondaryAnimation, child){
              return child;
            },)
      ),
      child: Hero(
        tag: brand,
        child: Card(
          elevation: 10,
          child: Container(
            width: width/3,
            height: width/6,
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage(brand),
                    fit: BoxFit.fill
                )
            ),
          ),
        ),
      ),
    );
  }
}
